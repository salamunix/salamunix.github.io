# Bootstrap-Portfolio
This is a template for a responsive portfolio website built with
[Twitter Bootstrap](http://getbootstrap.com/).
It's based off [this basic version](https://github.com/Meggin/Basic-Portfolio),
only now it behaves better across device sizes. Check out
[the staged version](https://protected-anchorage-85995.herokuapp.com/).

Feel free to fork and re-use:

`git clone https://github.com/Meggin/Bootstrap-Portfolio.git`

## Related custom CSS version
If you prefer to work with custom CSS,
here's a similar responsive portfolio website: [https://github.com/Meggin/Responsive-Portfolio](https://github.com/Meggin/Responsive-Portfolio).
